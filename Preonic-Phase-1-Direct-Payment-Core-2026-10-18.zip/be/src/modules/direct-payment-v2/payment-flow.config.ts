export type ContractPaymentFlow = 'direct_v2';

/**
 * New contracts always use direct settlement.
 *
 * Keeping this function centralizes the decision while legacy rows are migrated
 * in later phases. An environment variable must never be able to silently turn
 * Escrow V1 back on after the product has moved to direct settlement.
 */
export const getConfiguredContractPaymentFlow = (): ContractPaymentFlow =>
  'direct_v2';

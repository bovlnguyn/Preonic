import { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Phase 1 of the direct-settlement cutover.
 *
 * This migration is deliberately non-destructive: it makes Direct V2 the only
 * default for new contracts and adds the constraints/indexes required by the
 * active money flow. Historical Escrow/Wallet rows are retained until the
 * dedicated data-migration phase can archive and reconcile them safely.
 */
export class HardenDirectPaymentCore1792296000000 implements MigrationInterface {
  name = 'HardenDirectPaymentCore1792296000000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      IF COL_LENGTH('dbo.Contracts', 'PaymentFlow') IS NOT NULL
      BEGIN
        DECLARE @paymentFlowDefault sysname;
        SELECT @paymentFlowDefault = dc.name
        FROM sys.default_constraints dc
        JOIN sys.columns c ON c.default_object_id = dc.object_id
        WHERE dc.parent_object_id = OBJECT_ID('dbo.Contracts')
          AND c.name = 'PaymentFlow';

        IF @paymentFlowDefault IS NOT NULL
          EXEC('ALTER TABLE dbo.Contracts DROP CONSTRAINT [' + @paymentFlowDefault + ']');

        ALTER TABLE dbo.Contracts ADD CONSTRAINT DF_Contracts_PaymentFlow_Direct
          DEFAULT 'direct_v2' FOR PaymentFlow;
      END
    `);

    await queryRunner.query(`
      IF NOT EXISTS (
        SELECT 1 FROM sys.check_constraints
        WHERE name = 'CK_DirectGoodsPayments_DifferentParties'
          AND parent_object_id = OBJECT_ID('dbo.DirectGoodsPayments')
      )
      ALTER TABLE dbo.DirectGoodsPayments WITH CHECK
        ADD CONSTRAINT CK_DirectGoodsPayments_DifferentParties
        CHECK (PayerUserId <> PayeeUserId);
    `);

    await queryRunner.query(`
      IF NOT EXISTS (
        SELECT 1 FROM sys.check_constraints
        WHERE name = 'CK_DirectGoodsPayments_ConfirmedMetadata'
          AND parent_object_id = OBJECT_ID('dbo.DirectGoodsPayments')
      )
      ALTER TABLE dbo.DirectGoodsPayments WITH CHECK
        ADD CONSTRAINT CK_DirectGoodsPayments_ConfirmedMetadata
        CHECK (
          Status <> 'confirmed'
          OR (
            ConfirmedAt IS NOT NULL
            AND ConfirmedBy IS NOT NULL
            AND ConfirmationMethod IS NOT NULL
          )
        );
    `);

    await queryRunner.query(`
      IF NOT EXISTS (
        SELECT 1 FROM sys.check_constraints
        WHERE name = 'CK_DirectGoodsPayments_WholeVnd'
          AND parent_object_id = OBJECT_ID('dbo.DirectGoodsPayments')
      )
      ALTER TABLE dbo.DirectGoodsPayments WITH CHECK
        ADD CONSTRAINT CK_DirectGoodsPayments_WholeVnd
        CHECK (Amount > 0 AND Amount = ROUND(Amount, 0));
    `);

    await queryRunner.query(`
      IF NOT EXISTS (
        SELECT 1 FROM sys.indexes
        WHERE name = 'IX_Contracts_Product_Enterprise_Status_Delivery'
          AND object_id = OBJECT_ID('dbo.Contracts')
      )
      CREATE INDEX IX_Contracts_Product_Enterprise_Status_Delivery
        ON dbo.Contracts(ProductId, EnterpriseId, Status, DeliveryStatus)
        INCLUDE (FarmerId, ContractCode, DeliveryDate);
    `);

    await queryRunner.query(`
      IF NOT EXISTS (
        SELECT 1 FROM sys.indexes
        WHERE name = 'IX_DirectGoodsPayments_Contract_Status'
          AND object_id = OBJECT_ID('dbo.DirectGoodsPayments')
      )
      CREATE INDEX IX_DirectGoodsPayments_Contract_Status
        ON dbo.DirectGoodsPayments(ContractId, Status)
        INCLUDE (Amount, InstallmentSequence, ConfirmedAt);
    `);

    await queryRunner.query(`
      IF NOT EXISTS (
        SELECT 1 FROM sys.indexes
        WHERE name = 'IX_PlatformFeeLedgerEntries_User_Status_PostedAt'
          AND object_id = OBJECT_ID('dbo.PlatformFeeLedgerEntries')
      )
      CREATE INDEX IX_PlatformFeeLedgerEntries_User_Status_PostedAt
        ON dbo.PlatformFeeLedgerEntries(UserId, Status, PostedAt)
        INCLUDE (Direction, Amount, EntryType, FeeStatementId);
    `);

    await queryRunner.query(`
      IF NOT EXISTS (
        SELECT 1 FROM sys.indexes
        WHERE name = 'IX_PlatformFeeStatements_User_Status_DueAt'
          AND object_id = OBJECT_ID('dbo.PlatformFeeStatements')
      )
      CREATE INDEX IX_PlatformFeeStatements_User_Status_DueAt
        ON dbo.PlatformFeeStatements(UserId, Status, DueAt)
        INCLUDE (AmountDueSnapshot, AmountPaid);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_PlatformFeeStatements_User_Status_DueAt' AND object_id = OBJECT_ID('dbo.PlatformFeeStatements'))
        DROP INDEX IX_PlatformFeeStatements_User_Status_DueAt ON dbo.PlatformFeeStatements;
      IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_PlatformFeeLedgerEntries_User_Status_PostedAt' AND object_id = OBJECT_ID('dbo.PlatformFeeLedgerEntries'))
        DROP INDEX IX_PlatformFeeLedgerEntries_User_Status_PostedAt ON dbo.PlatformFeeLedgerEntries;
      IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_DirectGoodsPayments_Contract_Status' AND object_id = OBJECT_ID('dbo.DirectGoodsPayments'))
        DROP INDEX IX_DirectGoodsPayments_Contract_Status ON dbo.DirectGoodsPayments;
      IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Contracts_Product_Enterprise_Status_Delivery' AND object_id = OBJECT_ID('dbo.Contracts'))
        DROP INDEX IX_Contracts_Product_Enterprise_Status_Delivery ON dbo.Contracts;
    `);

    await queryRunner.query(`
      IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_DirectGoodsPayments_WholeVnd')
        ALTER TABLE dbo.DirectGoodsPayments DROP CONSTRAINT CK_DirectGoodsPayments_WholeVnd;
      IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_DirectGoodsPayments_ConfirmedMetadata')
        ALTER TABLE dbo.DirectGoodsPayments DROP CONSTRAINT CK_DirectGoodsPayments_ConfirmedMetadata;
      IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_DirectGoodsPayments_DifferentParties')
        ALTER TABLE dbo.DirectGoodsPayments DROP CONSTRAINT CK_DirectGoodsPayments_DifferentParties;
    `);

    await queryRunner.query(`
      IF COL_LENGTH('dbo.Contracts', 'PaymentFlow') IS NOT NULL
      BEGIN
        DECLARE @paymentFlowDefault sysname;
        SELECT @paymentFlowDefault = dc.name
        FROM sys.default_constraints dc
        JOIN sys.columns c ON c.default_object_id = dc.object_id
        WHERE dc.parent_object_id = OBJECT_ID('dbo.Contracts')
          AND c.name = 'PaymentFlow';

        IF @paymentFlowDefault IS NOT NULL
          EXEC('ALTER TABLE dbo.Contracts DROP CONSTRAINT [' + @paymentFlowDefault + ']');

        ALTER TABLE dbo.Contracts ADD CONSTRAINT DF_Contracts_PaymentFlow
          DEFAULT 'escrow_v1' FOR PaymentFlow;
      END
    `);
  }
}

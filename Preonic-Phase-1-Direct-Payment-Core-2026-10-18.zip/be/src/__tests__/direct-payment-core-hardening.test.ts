import { getMetadataArgsStorage } from 'typeorm';
import { Contract } from '../models/Contract.entity';
import { DirectGoodsPayment } from '../models/DirectGoodsPayment.entity';
import { HardenDirectPaymentCore1792296000000 } from '../migrations/HardenDirectPaymentCore1792296000000';
import { isDirectContractFulfilled } from '../utils/contract-completion.util';

describe('Direct payment core hardening', () => {
  test('fulfillment requires delivery and the whole contract value confirmed', () => {
    const base = {
      status: 'completed',
      deliveryStatus: 'delivered',
      totalValue: 10_000_000,
      paidAmount: 10_000_000,
      remainingAmount: 0,
    } as Contract;

    expect(isDirectContractFulfilled(base)).toBe(true);
    expect(isDirectContractFulfilled({ ...base, paidAmount: 9_000_000 })).toBe(false);
    expect(isDirectContractFulfilled({ ...base, deliveryStatus: 'shipping' })).toBe(false);
    expect(isDirectContractFulfilled({ ...base, status: 'active' })).toBe(false);
  });

  test('entities declare indexes used by payment and review queries', () => {
    const indexes = getMetadataArgsStorage().indices;
    const contractIndexes = indexes
      .filter((item) => item.target === Contract)
      .map((item) => item.name);
    const paymentIndexes = indexes
      .filter((item) => item.target === DirectGoodsPayment)
      .map((item) => item.name);

    expect(contractIndexes).toContain('IX_Contracts_Product_Enterprise_Status_Delivery');
    expect(paymentIndexes).toContain('IX_DirectGoodsPayments_Contract_Status');
  });

  test('migration changes the new-contract default without dropping legacy data', () => {
    const source = new HardenDirectPaymentCore1792296000000().up.toString();

    expect(source).toContain("DEFAULT 'direct_v2'");
    expect(source).toContain('CK_DirectGoodsPayments_DifferentParties');
    expect(source).toContain('CK_DirectGoodsPayments_ConfirmedMetadata');
    expect(source).toContain('IX_PlatformFeeLedgerEntries_User_Status_PostedAt');
    expect(source).not.toMatch(/DROP\s+TABLE/i);
    expect(source).not.toMatch(/DROP\s+COLUMN/i);
  });
});
